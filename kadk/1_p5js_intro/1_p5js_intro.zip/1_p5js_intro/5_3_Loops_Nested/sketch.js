function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(255);
  for (var x = 20; x <= width; x += 40) {
    for (var y = 20; y <= width; y += 40) {
      ellipse(x, y, 40);
    }
  }
}