function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background(0);
  beginShape();
  vertex(100, 100);
  vertex(200, 200);
  vertex(300, 100);
  vertex(300, 300);
  vertex(100, 300);
  endShape();
}