function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  
  stroke(0);
  fill(255,200,200);
  rect(50, 50, 300, 300); //Head
  
  fill(255);
  ellipse(150, 150, 75); //Left Eye
  ellipse(250, 150, 75); //Right Eye
  
  stroke(255,0,0);
  strokeWeight(10);
  line(200, 200, 250, 250); //Nose
  line(100, 250, 300, 300);	//Mouth
}