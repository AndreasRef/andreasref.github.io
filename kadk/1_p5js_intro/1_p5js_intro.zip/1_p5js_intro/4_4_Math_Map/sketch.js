function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(0);
  // Scale the mouseX value from 0 to 400 to a range between 40 and 175
  var d = map(mouseX, 0, width, 40, 175);
	// Scale the mouseY value from 0 to 400 to a range between 0 and 175
  var c = map(mouseY, 0, width, 0, 255);
  fill(122, c, 122);
  ellipse(width/2, height/2, d, d);   
}