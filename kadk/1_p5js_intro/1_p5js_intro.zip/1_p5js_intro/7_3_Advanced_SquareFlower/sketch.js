//Example taken from  http://btk.tillnagel.com/tutorials/rotation-translation-matrix.html
//Modified by Andreas Refsgaard

function setup() { 
  createCanvas(400, 400);
  rectMode(CENTER);
  stroke(30, 40);
} 

function draw() { 
  background(220);
  translate(width / 2, height / 2);
  for (var s = 270; s > 0; s = s - 10) {
    fill(255, 255 - s, 255 - s);
    rotate((mouseX + mouseY) / 300.0);
    rect(0, 0, s, s);
  }
}