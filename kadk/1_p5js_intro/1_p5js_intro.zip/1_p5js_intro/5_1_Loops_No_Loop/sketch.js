function setup() {
  createCanvas(400, 400);
}

function draw() {
  ellipse(20, 60, 40, 40);
  ellipse(60, 60, 40, 40);
  ellipse(100, 60, 40, 40);
  ellipse(140, 60, 40, 40);
}