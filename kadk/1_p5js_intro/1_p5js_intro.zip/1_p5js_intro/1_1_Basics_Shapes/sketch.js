function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  ellipse(50, 200, 50, 50);
  line(100, 150, 150, 250);
  rect(200, 200, 50, 50);
  triangle(300, 200, 350, 300, 400, 200);
}