function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  background(0);
  
  push();
  translate(200, 200);
  rotate(frameCount/50.0);
  beginShape();
  vertex(-100, -100);
  vertex(0, 0);
  vertex(100, -100);
  vertex(100, 100);
  vertex(-100, 100);
  endShape();
  pop();
}