var palette; 
var outerCircleColor, rectColor, innerCircleColor;

function setup() { 
  palette = [color('#FFFFFF'), 
             color('#CCCCCC'),
             color('#ECECEC'),
             color('#333333'), 
             color('#0095a8'), 
             color('#FF3300'), 
             color('#FF6600')
            ];

  updateColors();  
  createCanvas(400, 400);
  rectMode(CENTER);
} 

function draw() { 
  background(255);
  
  fill(outerCircleColor);
  ellipse(width/2, height/2, 400);

  fill(rectColor);
  rect(width/2, height/2, 200, 200);

  fill(innerCircleColor);
  ellipse(width/2, height/2, 100);
}

function mouseClicked() {
  updateColors();
}

function updateColors() {
  outerCircleColor = palette[floor(random(palette.length))];
  rectColor = palette[floor(random(palette.length))];
  innerCircleColor = palette[floor(random(palette.length))];
}