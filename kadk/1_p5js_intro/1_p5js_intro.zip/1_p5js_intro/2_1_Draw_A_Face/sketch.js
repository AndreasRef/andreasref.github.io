function setup() {
  createCanvas(400, 400);
}

function draw() {
  background(220);
  rect(50, 50, 300, 300);
  ellipse(150, 150, 75);
  ellipse(250, 150, 75);
  line(200, 200, 250, 250);
  line(100, 250, 300, 300);
}