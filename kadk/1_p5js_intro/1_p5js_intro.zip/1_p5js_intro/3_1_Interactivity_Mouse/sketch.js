function setup() { 
  createCanvas(800, 600);
  background(220);
} 

function draw() { 
  noFill();
  stroke(0,30);
  if (mouseIsPressed) ellipse(mouseX, mouseY, 50, 50);
}