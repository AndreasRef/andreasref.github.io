var bgColor; 
function setup() { 
  createCanvas(400, 400);
  bgColor = color(0);
} 

function draw() { 
	background(bgColor);
}

function keyTyped() {
  if (key === 'r') {
    bgColor = color (255,0,0);
  } else if (key === 'g') {
    bgColor = color (0,255,0);
  } else if (key === 'b') {
    bgColor = color (0,0,255);
  }
}