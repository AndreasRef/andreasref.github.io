function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  //background(220);
  fill(random(255), random(255),random(255));
  ellipse(random(width), random(height), random(40));
}