function setup() {
  createCanvas(400, 400);
  colorMode(HSB);
  noStroke();
}

function draw() {
  background(255);
  for (var x = 20; x <= width; x += 40) {
    for (var y = 20; y <= width; y += 40) {
      var d = sin(millis()/1000.0+y*0.01)*20+21;
      fill(sin(millis()/2000.0+x*0.001)*122+122, 150, 150);
      ellipse(x, y, d, d);
    }
  }
}