function setup() {
  createCanvas(400, 400);
}

function draw() {
  for (var x = 20; x <= width; x += 40) {
    ellipse(x, 20, 40);
  }
}