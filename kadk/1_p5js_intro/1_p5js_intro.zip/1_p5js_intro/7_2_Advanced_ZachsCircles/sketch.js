//Tweak of live code by Zach Lieberman 
//from https://www.youtube.com/watch?v=bmztlO9_Wvo&t=322s
//Needs a bit of cleaning

function setup() {
  createCanvas(400, 400);
  noStroke();
}

function draw() {
  background(0);

  var time = millis() / 1000.0;

  for (var i = 0; i < 300; i++) {
    fill(127 + 127 * sin(i * 0.01 + time),
      127 + 127 * sin(i * 0.011 + time),
      127 + 127 * sin(i * 0.012 + time));
    ellipse(200 + 100 * sin(i * 0.02 + time), 50 + i, 50, 50 + 40 * sin(i * 0.005 + time));
  }
}