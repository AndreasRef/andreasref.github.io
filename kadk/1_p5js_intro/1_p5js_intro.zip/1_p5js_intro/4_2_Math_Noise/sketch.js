var xoff = 0.0;
var yoff = 10.0;
function setup() { 
  createCanvas(400, 400);
} 

function draw() { 
  //background(204);
  var x = noise(xoff) * width;
  var y = noise(yoff) * height;
  
  ellipse(x, y, 40);
  xoff = xoff + 0.01;
  yoff = yoff + 0.01;
}